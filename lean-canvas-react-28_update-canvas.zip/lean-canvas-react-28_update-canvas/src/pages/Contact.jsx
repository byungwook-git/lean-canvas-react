function Contact() {
  return <div>Contact Page!</div>;
}

export default Contact;
